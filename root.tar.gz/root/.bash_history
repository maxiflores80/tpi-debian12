history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clear
cleart
clear
3e
clear
echo TPServer > /etc/hostname
sed -i 's/debian/TPServer/g' /etc/hosts
reboot
clear
cat /etc/hostname
cat /etc/hosts
clear
cat /etc/hosts
clear
ping -c 2 deb.debian.org
cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bookworm main contrib non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free-firmware
EOF

apt update
apt full-upgrade -y
reboot
lsb_release -a
clear
apt update
apt full-upgrade -y
reboot
lsb_release -a
cd /root
ls
tar -xzf Material_Adicional_TPVMCA.tar.gz
ls Material_Adicional_TPVMCA
apt install openssh-server -y
systemctl enable --now ssh
mkdir -p /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/autorized_keys
chmod 700 /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
sed -i 's/^#\?PubkeyAuthentication.*/PubkeyAuthentication yes/' /etc/ssh/sshd_config
grep -E "^(PermitRootLogin|PubkeyAuthentication)" /etc/ssh/sshd_config
clear
systemctl restart ssh
systemctl status ssh
q
clear
apt install apache2 php libapache2-mod-php php-mysql -y
clear
systemctl enable --now apache2
clear
php -v
apt install mariadb-server -y
systemctl enable --now mariadb
clear
mysql -u root -e "show databases;"
clear
systemctl status apache2
systemsctl status maridb
systemctl status mariadb
ip a
clear
ip a
ip config
ip route
clear
ping -c 2 192.168.18.150
clear
cat > /etc/network/interfaces << 'EOF'
source /etc/network/interfaces.d/*
auto lo
iface lo inet loopback
allow-hotplug enp0s3
iface enp0s3 inet static
address 192.168.18.150
netmask 255.255.255.0
gateway 192.168.18.1
EOF

clear
cat /etc/network/interfaces
clear
systemctl restart networking 
ip a
clear
ping -c 2 192.168.18.1
clear
ping -c 2 deb.debian.org
clear
cat /root/Material_Adicional_TPVMCA/clave_privada.txt
clear
sed -i 's/^PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
systemctl restart ssh
sed -i 's/^PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
systemctl restart ssh
grep ^PermitRootLogin /etc/ssh/sshd_config
clear
poweroff
grep ^PermitRootLogin /etc/ssh/sshd_config
