#!/bin/bash

# 1. Opcion de ayuda
if [[ "$1" == "-help" || "$1" == "--help" || "$1" == "-h" ]]; then
    echo "=========================================="
    echo "AYUDA - SCRIPT DE RESPALDO (backup_full.sh)"
    echo "=========================================="
    echo "Uso: $0 <origen> <destino>"
    echo "Descripcion: respalda en un .tar.gz el origen indicado,"
    echo "             lo guarda en el destino y agrega la fecha"
    echo "             en formato ANSI (YYYYMMDD) al nombre."
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "         genera /backup_dir/log_bkp_YYYYMMDD.tar.gz"
    echo "=========================================="
    exit 0
fi

# 2. Validacion de argumentos (exactamente 2)
if [ $# -ne 2 ]; then
    echo "Error: cantidad de argumentos incorrecta."
    echo "Uso correcto: $0 <origen> <destino>"
    echo "Ejecute '$0 -help' para obtener ayuda."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# 3. Validacion de disponibilidad de origen y destino
if [ ! -e "$ORIGEN" ]; then
    echo "Error: el origen '$ORIGEN' no existe o no esta disponible."
    exit 2
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el destino '$DESTINO' no existe o no esta montado."
    exit 3
fi

# 4. Nombre del archivo con fecha ANSI
FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

# 5. Compresion y control de salida
tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "Exito: respaldo de '$ORIGEN' guardado en '$DESTINO/$ARCHIVO'."
    exit 0
else
    echo "Error: fallo el proceso de compresion y respaldo."
    exit 4
fi
